# ChatBot
The 1st project of CC

Team Member: Jiachen Du   UNI:jd3488
             Yuqin   Xu   UNI:yx2478
             
Log in information: Username:admin   Password:123456
